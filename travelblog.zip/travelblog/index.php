<!DOCTYPE html>
<!--
	Future Imperfect by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
  <head>
    <title>Asian Travel Blog</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, user-scalable=no"
    />
    <link rel="stylesheet" href="assets/css/main.css" />
  </head>
  <body class="is-preload">
    <!-- Wrapper -->
    <div id="wrapper">
      <!-- Header -->
      <header id="header">
        <h1><a href="index.html">Asian Travel Blog</a></h1>
        <nav class="links">
          <ul>
            <li><a href="#">Travel</a></li>
            <li><a href="#">Pictures</a></li>
            <li><a href="#">Tips</a></li>
          </ul>
        </nav>
        <nav class="main">
          <ul>
            <li class="search">
              <a class="fa-search" href="#search">Search</a>
              <form id="search" method="get" action="#">
                <input type="text" name="query" placeholder="Search" />
              </form>
            </li>
            <li class="menu">
              <a class="fa-bars" href="#menu">Menu</a>
            </li>
          </ul>
        </nav>
      </header>

      <!-- Menu -->
      <section id="menu">
        <!-- Search -->
        <section>
          <form class="search" method="get" action="#">
            <input type="text" name="query" placeholder="Search" />
          </form>
        </section>

        <!-- Links -->
        <section>
          <ul class="links">
            <li>
              <a href="#">
                <h3>Lorem ipsum</h3>
                <p>Feugiat tempus veroeros dolor</p>
              </a>
            </li>
            <li>
              <a href="#">
                <h3>Dolor sit amet</h3>
                <p>Sed vitae justo condimentum</p>
              </a>
            </li>
            <li>
              <a href="#">
                <h3>Feugiat veroeros</h3>
                <p>Phasellus sed ultricies mi congue</p>
              </a>
            </li>
            <li>
              <a href="#">
                <h3>Etiam sed consequat</h3>
                <p>Porta lectus amet ultricies</p>
              </a>
            </li>
          </ul>
        </section>

        <!-- Actions -->
        <section>
          <ul class="actions stacked">
            <li><a href="#" class="button large fit">Log In</a></li>
          </ul>
        </section>
      </section>

      <!-- Main -->
      <div id="main">
        <!-- Post -->
        <article class="post">
          <header>
            <div class="title">
              <h2><a href="single.html">The amazing Malaysia</a></h2>
              <p>Kuala Lumpur, much more than the Petronas twin Towers</p>
            </div>
            <div class="meta">
              <time class="published" datetime="2015-10-22"
                >October 22, 2015</time
              >
              <a href="#" class="author"
                ><span class="name">Ibtissam Liedri</span
                ><img src="images/avatar.jpg" alt=""
              /></a>
            </div>
          </header>
          <a href="single.html" class="image featured"
            ><img src="images/malaysia.jpeg" alt=""
          /></a>
          <p>
            Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl.
            Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna
            enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
            congue ullam corper. Praesent tincidunt sed tellus ut rutrum. Sed
            vitae justo condimentum, porta lectus vitae, ultricies congue
            gravida diam non fringilla. Cras vehicula tellus eu ligula viverra,
            ac fringilla turpis suscipit. Quisque vestibulum rhoncus ligula.
          </p>
          <footer>
            <ul class="actions">
              <li>
                <a href="single.html" class="button large">Continue Reading</a>
              </li>
            </ul>
            <ul class="stats">
              <li><a href="#">General</a></li>
              <li><a href="#" class="icon solid fa-heart">28</a></li>
              <li><a href="#" class="icon solid fa-comment">128</a></li>
            </ul>
          </footer>
        </article>

        <!-- Post -->
        <article class="post">
          <header>
            <div class="title">
              <h2><a href="single.html">Visiting Singapore</a></h2>
              <p>The magnificent Marina Bay Sands</p>
            </div>
            <div class="meta">
              <time class="published" datetime="2015-11-01"
                >November 1, 2023</time
              >
              <a href="#" class="author"
                ><span class="name">Hanna Morgenstern</span
                ><img src="images/avatar.jpg" alt=""
              /></a>
            </div>
          </header>
          <a href="single.html" class="image featured"
            ><img src="images/singapore.jpeg" alt=""
          /></a>
          <p>
            Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl.
            Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna
            enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
            congue ullam corper. Praesent tincidunt sed tellus ut rutrum. Sed
            vitae justo condimentum, porta lectus vitae, ultricies congue
            gravida diam non fringilla.
          </p>
          <footer>
            <ul class="actions">
              <li>
                <a href="single.html" class="button large">Continue Reading</a>
              </li>
            </ul>
            <ul class="stats">
              <li><a href="#">General</a></li>
              <li><a href="#" class="icon solid fa-heart">28</a></li>
              <li><a href="#" class="icon solid fa-comment">128</a></li>
            </ul>
          </footer>
        </article>

        <!-- Post -->
        <article class="post">
          <header>
            <div class="title">
              <h2>
                <a href="single.html">Exploring Vietnam</a>
              </h2>
              <p>More than just Pho</p>
            </div>
            <div class="meta">
              <time class="published" datetime="2015-10-25"
                >October 25, 2015</time
              >
              <a href="#" class="author"
                ><span class="name">Sidra Ahmed</span
                ><img src="images/avatar.jpg" alt=""
              /></a>
            </div>
          </header>
          <a href="single.html" class="image featured"
            ><img src="images/vietnam.jpeg" alt=""
          /></a>
          <p>
            Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl.
            Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna
            enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
            congue ullam corper.
          </p>
          <footer>
            <ul class="actions">
              <li>
                <a href="single.html" class="button large">Continue Reading</a>
              </li>
            </ul>
            <ul class="stats">
              <li><a href="#">General</a></li>
              <li><a href="#" class="icon solid fa-heart">28</a></li>
              <li><a href="#" class="icon solid fa-comment">128</a></li>
            </ul>
          </footer>
        </article>

        <!-- Pagination -->
        <ul class="actions pagination">
          <li>
            <a href="" class="disabled button large previous">Previous Page</a>
          </li>
          <li><a href="#" class="button large next">Next Page</a></li>
        </ul>
      </div>

      <!-- Sidebar -->
      <section id="sidebar">
        <!-- Intro -->
        <section id="intro">
          <a href="#" class="logo"><img src="images/techu.png" alt="" /></a>
          <header>
            <h2>Asian Travel Blog</h2>
            <p>Visiting the oriental world</p>
<?php
# Get the instance ID from meta-data and store it in the $instance_id variable
$url = "http://169.254.169.254/latest/meta-data/instance-id";
$instance_id = file_get_contents($url);
# Get the instance's availability zone from metadata and store it in the $zone variable
$url = "http://169.254.169.254/latest/meta-data/placement/availability-zone";
$zone = file_get_contents($url);
?>
            <p>EC2 Instance ID: <?php echo $instance_id; ?></p>
            <p>Zone: <?php echo  $zone; ?></p>
          </header>
        </section>

        <!-- Mini Posts -->
        <section>
          <div class="mini-posts">
            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Indonesia</a></h3>
                <time class="published" datetime="2015-10-20"
                  >October 20, 2015</time
                >
                <a href="#" class="author"
                  ><img src="images/avatar.jpg" alt=""
                /></a>
              </header>
              <a href="single.html" class="image"
                ><img src="images/indonesia.jpeg" alt=""
              /></a>
            </article>

            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Thailand</a></h3>
                <time class="published" datetime="2015-10-19"
                  >October 19, 2015</time
                >
                <a href="#" class="author"
                  ><img src="images/avatar.jpg" alt=""
                /></a>
              </header>
              <a href="single.html" class="image"
                ><img src="images/thailand.jpeg" alt=""
              /></a>
            </article>

            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">South Korea</a></h3>
                <time class="published" datetime="2015-10-18"
                  >October 18, 2015</time
                >
                <a href="#" class="author"
                  ><img src="images/avatar.jpg" alt=""
                /></a>
              </header>
              <a href="single.html" class="image"
                ><img src="images/southkorea.jpeg" alt=""
              /></a>
            </article>

            <!-- Mini Post -->
            <article class="mini-post">
              <header>
                <h3><a href="single.html">Phillipines</a></h3>
                <time class="published" datetime="2015-10-17"
                  >October 17, 2015</time
                >
                <a href="#" class="author"
                  ><img src="images/avatar.jpg" alt=""
                /></a>
              </header>
              <a href="single.html" class="image"
                ><img src="images/phillipines.jpeg" alt=""
              /></a>
            </article>
          </div>
        </section>

        <!-- Posts List -->
        <section>
          <ul class="posts">
            <li>
              <article>
                <header>
                  <h3>
                    <a href="single.html">Uzbekistan</a>
                  </h3>
                  <time class="published" datetime="2015-10-20"
                    >October 20, 2015</time
                  >
                </header>
                <a href="single.html" class="image"
                  ><img src="images/pic08.jpg" alt=""
                /></a>
              </article>
            </li>
            <li>
              <article>
                <header>
                  <h3>
                    <a href="single.html">Myanmar</a>
                  </h3>
                  <time class="published" datetime="2015-10-15"
                    >October 15, 2015</time
                  >
                </header>
                <a href="single.html" class="image"
                  ><img src="images/pic09.jpg" alt=""
                /></a>
              </article>
            </li>
            <li>
              <article>
                <header>
                  <h3>
                    <a href="single.html">Cambodia</a>
                  </h3>
                  <time class="published" datetime="2015-10-10"
                    >October 10, 2015</time
                  >
                </header>
                <a href="single.html" class="image"
                  ><img src="images/pic10.jpg" alt=""
                /></a>
              </article>
            </li>
            <li>
              <article>
                <header>
                  <h3>
                    <a href="single.html">Taiwan</a>
                  </h3>
                  <time class="published" datetime="2015-10-08"
                    >October 8, 2015</time
                  >
                </header>
                <a href="single.html" class="image"
                  ><img src="images/pic11.jpg" alt=""
                /></a>
              </article>
            </li>
            <li>
              <article>
                <header>
                  <h3>
                    <a href="single.html">Nepal</a>
                  </h3>
                  <time class="published" datetime="2015-10-06"
                    >October 7, 2015</time
                  >
                </header>
                <a href="single.html" class="image"
                  ><img src="images/pic12.jpg" alt=""
                /></a>
              </article>
            </li>
          </ul>
        </section>

        <!-- About -->
        <section class="blurb">
          <h2>About</h2>
          <p>
            This is a travel blog was developed by a scrum group of TechU LHR2
            as a POC for showing AWS Web Services capabilities.
          </p>
          <ul class="actions">
            <li><a href="#" class="button">Learn More</a></li>
          </ul>
        </section>

        <!-- Footer -->
        <section id="footer">
          <ul class="icons">
            <li>
              <a href="#" class="icon brands fa-twitter"
                ><span class="label">Twitter</span></a
              >
            </li>
            <li>
              <a href="#" class="icon brands fa-facebook-f"
                ><span class="label">Facebook</span></a
              >
            </li>
            <li>
              <a href="#" class="icon brands fa-instagram"
                ><span class="label">Instagram</span></a
              >
            </li>
            <li>
              <a href="#" class="icon solid fa-rss"
                ><span class="label">RSS</span></a
              >
            </li>
            <li>
              <a href="#" class="icon solid fa-envelope"
                ><span class="label">Email</span></a
              >
            </li>
          </ul>
          <p class="copyright">
            &copy; Untitled. Design: <a href="http://html5up.net">HTML5 UP</a>.
            Images: <a href="http://unsplash.com">Unsplash</a>.
          </p>
        </section>
      </section>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
